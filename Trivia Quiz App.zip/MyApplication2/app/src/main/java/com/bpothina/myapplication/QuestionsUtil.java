package com.bpothina.myapplication;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by BhaBhaHP on 9/27/2017.
 */

public class QuestionsUtil {


        static public class QuestionsJSONParser{
            static String id,text,image,answer;
            static ArrayList<String> choices=new ArrayList<String>();

            static ArrayList<Questions> parseQuestions(String in) throws JSONException {
            ArrayList<Questions> questionsList = new ArrayList<Questions>();
                Log.d("demo123","entered util");
                JSONObject root = new JSONObject(in);
                //Log.d("demoutil",root.toString());

                JSONArray questionsJSONArray = root.getJSONArray("questions");
                try {
                    for (int i = 0; i < questionsJSONArray.length(); i++) {
                        //Log.d("demo123", "entered loop"+i);
                        JSONObject questionsJSONObject = questionsJSONArray.getJSONObject(i);
                        //Questions questions = new Questions();
                        //questions.setId(questionsJSONObject.getString("id"));
                        id=questionsJSONObject.getString("id");
                        //Log.d("demo",recipe.getTitle());
                        if(!questionsJSONObject.has("image")) {
                           //Log.d("demo","no image" +i);
                            //questions.setImage("NA");
                            image="NA";
                        }
                        else {
                            //questions.setImage(questionsJSONObject.getString("image"));
                            image=questionsJSONObject.getString("image");
                        }
                        //questions.setText(questionsJSONObject.getString("text"));
                        //Log.d("demo",questions.getText());
                        text=questionsJSONObject.getString("text");

                        JSONObject choicesJSONObject = questionsJSONObject.getJSONObject("choices");

                        //questions.setAnswer(choicesJSONObject.getString("answer"));
                        answer=choicesJSONObject.getString("answer");
                        Log.d("answer",answer);
                        JSONArray choicesJSONArray=choicesJSONObject.getJSONArray("choice");
                        Log.d("choices-length", String.valueOf(choicesJSONArray.length()));
                        choices=new ArrayList<String>();
                        for(int j=0;j<choicesJSONArray.length();j++)
                        {
                        //questions.setChoices(choicesJSONArray.getString(j));

                            choices.add(choicesJSONArray.getString(j));
                        }
                       // questions.setChoices(questionsJSONObject.getString("choices"));
                        //Log.d("demo123", questions.toString());
                        Log.d("choices adding", String.valueOf(choices));
                        Questions question=new Questions(id,text,image,answer,choices);

                        questionsList.add(question);
                    }
                }
                catch (Exception e)
                {
                    Log.d("Exception",e.toString());
                }
                Log.d("demo-util", String.valueOf(questionsList.size()));
                Log.d("demo-util","exit util");
                Log.d("length", String.valueOf(questionsList.size()));
                return questionsList;
            }
        }


}
