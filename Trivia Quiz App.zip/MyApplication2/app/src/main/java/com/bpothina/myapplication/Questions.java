package com.bpothina.myapplication;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by BhaBhaHP on 9/27/2017.
 */

public class Questions implements Serializable {


     String id,text,image,answer;

    ArrayList<String> choices=new ArrayList<String>();
    ArrayList<Questions> questions=new ArrayList<Questions>();
//    String[] choice;


    public void setChoices(ArrayList<String> choices) {
        this.choices = choices;
    }

    public ArrayList<Questions> getQuestions() {
        return questions;
    }

    public void setQuestions(ArrayList<Questions> questions) {
        this.questions = questions;
    }

    public Questions(String id, String text, String image, String answer, ArrayList<String> choices) {
        this.id = id;
        this.text = text;
        this.image = image;
        this.answer = answer;
        this.choices = choices;
    }

    protected Questions(Parcel in) {
        id = in.readString();
        text = in.readString();
        image = in.readString();
        answer = in.readString();
        choices = in.createStringArrayList();
       // choice = in.createStringArray();
    }

//    public static final Creator<Questions> CREATOR = new Creator<Questions>() {
//        @Override
//        public Questions createFromParcel(Parcel in) {
//            return new Questions(in);
//        }
//
//        @Override
//        public Questions[] newArray(int size) {
//            return new Questions[size];
//        }
//    };

//    public String[] getChoice() {
//        return choice;
//    }
//
//    public void setChoice(String[] choice) {
//        this.choice = choice;
//    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public ArrayList<String> getChoices() {
        return choices;
    }

    public void setChoices(String choices) {
        Log.d("choices",choices);
        this.choices.add(choices);
    }

//    @Override
//    public int describeContents() {
//        return 0;
//    }
//
//    @Override
//    public void writeToParcel(Parcel parcel, int i) {
//        parcel.writeString(id);
//        parcel.writeString(text);
//        parcel.writeString(image);
//        parcel.writeString(answer);
//        parcel.writeStringList(choices);
//        //parcel.writeStringArray(choice);
//    }

//    @Override
//    public String toString() {
//        return "Questions{" +
//                "id='" + id + '\'' +
//                ", text='" + text + '\'' +
//                ", image='" + image + '\'' +
//                ", answer='" + answer + '\'' +
//                ", choices=" + Arrays.toString(choices) +
//                '}';
//    }
}
