package com.bpothina.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.bpothina.myapplication.MainActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import static com.bpothina.myapplication.MainActivity.p1;

/**
 * Created by BhaBhaHP on 9/29/2017.
 */

public class GetImage extends AsyncTask<String,Integer,Bitmap>
{

    TriviaActivity triviaActivity;
    ImageView image;
    LinearLayout linearLayout;
    TextView t;
    ProgressBar p1;

    public GetImage(TriviaActivity activity, LinearLayout linear,ProgressBar p1)
    {
        triviaActivity = activity;
        //this.image=image;
        this.linearLayout=linear;
        this.p1=p1;
    }
    @Override
    protected Bitmap doInBackground(String... strings) {
        URL url1 = null;
        try
        {
                url1 = new URL(strings[0]);
            HttpURLConnection con = (HttpURLConnection) url1.openConnection();
            con.setRequestMethod("GET");
            Bitmap image = BitmapFactory.decodeStream(con.getInputStream());

            for(int i=0;i<10000;i++)
                publishProgress(i);

            return image;

        }
        catch (Exception ex)
        {
            Log.d("exception",ex.toString());
        }

        return null;
    }



    @Override
    protected void onPreExecute() {

        p1.setVisibility(View.VISIBLE);
        t=new TextView(triviaActivity);
        //LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 20));

        t.setTextSize(20);
        t.setText("Loading Image");

        //t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setId(View.generateViewId());
        linearLayout.addView(t);
        super.onPreExecute();
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        p1.setVisibility(View.VISIBLE);
        p1.setProgress(values[0]);
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(Bitmap image) {

        triviaActivity.setImage(image,t,linearLayout);
        linearLayout.removeView(t);
        ImageView imageView = new ImageView(triviaActivity);
        p1.setLayoutParams(new LinearLayout.LayoutParams(150,150));

//            setImageBitmap=image;
//            ImageView img=(ImageView)findViewById(R.id.dish_image);
//            img.setImageBitmap(image);

    }


}
