package com.bpothina.myapplication;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    public LinearLayout linearLayout;
    public int progressId;
    public static ProgressBar p1;
    public static TextView t;

    ArrayList<Questions> questions=new ArrayList<Questions>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        linearLayout=(LinearLayout)findViewById(R.id.linear_layoutMain);
        setContentView(linearLayout);
        linearLayout=(LinearLayout)findViewById(R.id.linear_layout);

        p1 = new ProgressBar(MainActivity.this,null,android.R.attr.progressBarStyle);
        p1.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, 400));
        //p1.setPadding(100,0,40,0);
        p1.setPadding(50,0,40,0);
        p1.setId(View.generateViewId());
        p1.setProgress(0);
        progressId = p1.getId();
        p1.setMax(100);
        linearLayout.addView(p1);
        Button button=(Button)findViewById(R.id.start);
        button.setEnabled(false);

        Log.d("demo","calling getData");
       new GetData(this,linearLayout,button).execute("http://dev.theappsdr.com/apis/trivia_json/index.php");

    }



    public void getQuestions(ArrayList<Questions> questionsList)
    {
        this.questions=questionsList;

        //Log.d("questions123", String.valueOf(questions.size()));
    }
    public void Action(View view)
    {
        Log.d("demo","entered");
        if(view.getId()==R.id.exit)
        {
            finish();
        }
        else {
            //Toast.makeText(getBaseContext(),"done",Toast.LENGTH_LONG).show();

            Intent intent=new Intent(MainActivity.this,TriviaActivity.class);
            //intent.putParcelableArrayListExtra("questions",questions);
            intent.putExtra("questions", questions);
           //Log.d("error","error");
            startActivity(intent);
        }
    }



}
