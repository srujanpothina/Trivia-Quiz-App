package com.bpothina.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.opengl.Visibility;
import android.os.CountDownTimer;
import android.support.v4.graphics.BitmapCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class TriviaActivity extends AppCompatActivity {

    ArrayList<Questions> questions=new ArrayList<Questions>();
     Boolean flag = true;
    int correctAnswerCount=0;
    LinearLayout linearLayout;
    RadioGroup rg;
    int RadioGroupId;
    ProgressBar p1;
    int progressId;
    ImageView img;
    int questionCount=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia);

        if(getIntent().getExtras()!=null)
        {
            //questions=getIntent().getParcelableArrayListExtra("questions");
            questions = (ArrayList<Questions>) getIntent().getSerializableExtra("questions");
            //Toast.makeText(getBaseContext(),String.valueOf(questions.size()),Toast.LENGTH_LONG).show();

            Log.d("demo-values", String.valueOf(questions.size()));

        }

        final TextView tv=(TextView)findViewById(R.id.textView2);

        new CountDownTimer(120000, 1000) {

            public void onTick(long millisUntilFinished) {
                tv.setText("Time Left: " + millisUntilFinished / 1000 +" seconds");
            }

            public void onFinish() {
                if(flag){
                    End();
                }

            }
        }.start();
        //Log.d("radio","radio");

        addRadioButtons(questionCount);

//        CountDownTimer countDownTimer=new CountDownTimer() {
//            @Override
//            public void onTick(long l) {
//
//            }
//
//            @Override
//            public void onFinish() {
//
//            }
//        }
    }
    public void onQuit(View view) {
        finish();
    }

    public void End()
    {
        Intent stats=new Intent(TriviaActivity.this,Stats.class);
        stats.putExtra("correct",correctAnswerCount);
        Log.d("stats", String.valueOf(correctAnswerCount));
        stats.putExtra("questions", questions);
        finish();
        startActivity(stats);
    }

    public void onNext(View view){

//        if(questionCount>15)
//        {
//            End();
//        }
//        else {
            RadioGroup radioGroup = (RadioGroup) findViewById(RadioGroupId);
            int selectedId = radioGroup.getCheckedRadioButtonId();
            Log.d("id", String.valueOf(selectedId));

            // find the radiobutton by returned id
            RadioButton radioButton = (RadioButton) findViewById(selectedId);
            Log.d("Data-answer",questions.get(questionCount).answer);
            Log.d("Data-given option",String.valueOf(questions.get(questionCount).choices.indexOf(radioButton.getText())+1));
            //Log.d("demo321", questions.get(questionCount).answer);
            //Log.d("demo321", String.valueOf(radioButton.getText()));
            //Log.d("demo321",String.valueOf(questions.get(questionCount).choices.indexOf(radioButton.getText()) + 1));
            if (questions.get(questionCount).answer.equals(String.valueOf(questions.get(questionCount).choices.indexOf(radioButton.getText()) + 1))){

                correctAnswerCount++;

                Log.d("Data: ","correct count: "+correctAnswerCount +"  Question Count:"+ questionCount);

            }

            questionCount++;

            if(questionCount == 16){
                questionCount = 0;
                flag = false;
                End();
            } else

              addRadioButtons(questionCount);

        //}
    }

    public void setImage(Bitmap image,TextView t,LinearLayout linearLayout)
    {
        //ImageView img=(ImageView)findViewById(R.id.image) ;
        linearLayout.removeView(t);
        linearLayout = (LinearLayout) findViewById(R.id.linear_trivia);
        setContentView(linearLayout);
        LinearLayout l1 = (LinearLayout) findViewById(R.id.image_layout);
        setContentView(linearLayout);
        l1.removeView(img);
        Log.d("image","remove existing image");
        img=new ImageView(this);

//         <!--<ImageView-->
//            <!--android:layout_marginTop="10dp"-->
//            <!--android:layout_marginLeft="17dp"-->
//            <!--android:layout_width="355dp"-->
//            <!--android:layout_height="124dp"-->
//            <!--android:id="@id/image"-->
//
//            <!--/>-->
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        img.setLayoutParams(l);
//        img.setMaxHeight(50);
//        img.setMaxWidth(50);

        l1.addView(img);
        p1.setVisibility(View.GONE);
        l1.removeView(p1);
        l1.removeView(t);
        Log.d("image","remove progress and text box");
        img.setImageBitmap(image);
        Log.d("image","new image set");

    }


    public void setProgressbar()
    {
        Log.d("image","progress create");
        linearLayout=(LinearLayout)findViewById(R.id.linear_trivia);
        setContentView(linearLayout);
        linearLayout=(LinearLayout)findViewById(R.id.image_layout);

        p1 = new ProgressBar(TriviaActivity.this,null,android.R.attr.progressBarStyle);
        p1.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, 200));
        //p1.setPadding(100,0,40,0);
        p1.setPadding(50,0,40,0);
        p1.setId(View.generateViewId());
        p1.setProgress(0);
        progressId = p1.getId();
        p1.setMax(100);
        p1.setVisibility(View.VISIBLE);
        linearLayout.addView(p1);
    }


    public void addRadioButtons(int number) {
        linearLayout = (LinearLayout) findViewById(R.id.linear_trivia);
        setContentView(linearLayout);
        LinearLayout l1 = (LinearLayout) findViewById(R.id.radio_layout);

        setContentView(linearLayout);
        l1.removeView(rg);
        Log.d("radio","radio"+number);
        linearLayout = (LinearLayout) findViewById(R.id.linear_trivia);
        setContentView(linearLayout);
        l1 = (LinearLayout) findViewById(R.id.radio_layout);
        setContentView(linearLayout);
        //ImageView image=(ImageView)findViewById(R.id.image) ;
        LinearLayout l=(LinearLayout)findViewById(R.id.image_layout);
        l.removeView(img);
        if(!(questions.get(number).image=="NA")) {
            setProgressbar();
            new GetImage(this, l, p1).execute(questions.get(number).image);
        }
         rg=new RadioGroup(this);
        RadioGroupId=View.generateViewId();
        rg.setId(RadioGroupId);
        rg.setLayoutParams(new RadioGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        //RadioGroup r1 = (RadioGroup) findViewById(R.id.radioGroup);
        l1.addView(rg);


        TextView t=(TextView)findViewById(R.id.textView);
        t.setText("Q"+(number+1));
        TextView questionText=(TextView)findViewById(R.id.question);
        questionText.setText(questions.get(number).text);
        int choicesCount = questions.get(number).choices.size();


        for (int row = 0; row < choicesCount; row++) {
            //r1.setOrientation(LinearLayout.HORIZONTAL);
                RadioButton rdbtn = new RadioButton(this);
                rdbtn.setId(row+1);
                rdbtn.setText(questions.get(number).choices.get(row));
                rg.addView(rdbtn);
        }
    }
}
