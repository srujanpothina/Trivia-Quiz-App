package com.bpothina.myapplication;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.bpothina.myapplication.MainActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import static com.bpothina.myapplication.MainActivity.p1;
import static com.bpothina.myapplication.MainActivity.t;

/**
 * Created by BhaBhaHP on 9/27/2017.
 */


public class GetData extends AsyncTask<String,Integer,ArrayList<Questions>>

{

    MainActivity mainActivity;
    public LinearLayout linearLayout;
    public int progressId;
    Button button;
    ArrayList<Questions> list=new ArrayList<Questions>();

    public GetData(MainActivity activity,LinearLayout linearLayout,Button button)
    {
        mainActivity = activity;
        this.linearLayout=linearLayout;
        this.button=button;

    }
    @Override
    protected void onPreExecute() {

        p1.setVisibility(View.VISIBLE);
        t=new TextView(mainActivity);
        //LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        t.setTextSize(20);
        t.setText("Loading Trivia");

        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setId(View.generateViewId());
        linearLayout.addView(t);

        Log.d("demo","added p1 and t");
        super.onPreExecute();

    }
    @Override
    protected void onProgressUpdate(Integer... values) {

        p1.setProgress(values[0]);
        Log.d("demo-progress", String.valueOf(values[0]));
        super.onProgressUpdate(values);
    }

    @Override
    protected ArrayList<Questions> doInBackground(String... params) {
        BufferedReader reader = null;
        StringBuilder sb=new StringBuilder();
        try
        {
           // Log.d("demo",params[0]);
            URL url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();

            reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            sb= new StringBuilder();
            String line = "";
            while ((line = reader.readLine()) != null)
            {
                sb.append(line);
            }
           list=QuestionsUtil.QuestionsJSONParser.parseQuestions(sb.toString());
            for(int i=0;i<list.size()*100;i++) {
                Log.d("demo-progress", String.valueOf(i));
                publishProgress(i);
            }

            Log.d("demo-result-JSON parse",list.toString());
            return list ;



        }
        catch (Exception ex)
        {

        }

        return null;
    }

    @Override
    protected void onPostExecute(ArrayList<Questions> questions) {

        //Log.d("demo onpostexex",questions.get(0).choices.toString());

        mainActivity.getQuestions(questions);

        MainActivity.p1.setVisibility(View.GONE);
        ((ViewGroup)linearLayout.getParent()).removeView(p1);

        linearLayout.removeView(t);


        ImageView imageView = new ImageView(mainActivity);
        //p1.setLayoutParams(new LinearLayout.LayoutParams(150,150));
        imageView.setImageResource(R.drawable.trivia);
        imageView.setId(View.generateViewId());
        imageView.setPadding(50,0,0,0);
        linearLayout.addView(imageView);

        TextView t=new TextView(mainActivity);
        t.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        t.setTextSize(20);
        t.setPadding(360,0,0,0);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setText("Trivia Ready");

        Log.d("demo","removed and set image and text");
        t.setId(View.generateViewId());
        linearLayout.addView(t);
        button.setEnabled(true);

    }
}

