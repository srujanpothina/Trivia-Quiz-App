package com.bpothina.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Stats extends AppCompatActivity {

    int correctAnswers;
    ArrayList<Questions> questions=new ArrayList<Questions>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        if(getIntent().getExtras()!=null)
        {
             correctAnswers=getIntent().getIntExtra("correct",0);
            questions = (ArrayList<Questions>) getIntent().getSerializableExtra("questions");
            //questions=getIntent().getParcelableArrayListExtra("questions");
//            correctAnswers=Integer.parseInt(getIntent().getExtras().getString("TotalSum"));
            Log.d("demoanswer", String.valueOf(correctAnswers));
        }

        TextView tv=(TextView)findViewById(R.id.textView5);
        tv.setText(correctAnswers*100/16+"%");
        ProgressBar pb=(ProgressBar)findViewById(R.id.progressBar);
        pb.setMax(16);
        //correctAnswers=correctAnswers*100/16;
        pb.setProgress(correctAnswers);

        TextView stmt=(TextView)findViewById(R.id.textView6);
        if(correctAnswers==16)
        {
            stmt.setVisibility(View.GONE);
        }
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        findViewById(R.id.button1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Stats.this,TriviaActivity.class);
                //intent.putParcelableArrayListExtra("questions",questions);
                intent.putExtra("questions", questions);
                //Log.d("error","error");
                finish();
                startActivity(intent);
            }
        });
    }
}
